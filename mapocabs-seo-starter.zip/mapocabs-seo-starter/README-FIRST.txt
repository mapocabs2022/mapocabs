MAPOCABS SEO STARTER — GITHUB PAGES
=====================================

WHAT'S INCLUDED
- /blog/ index page and three original starter articles
- /services/ index page and four service enquiry pages
- Shared responsive CSS
- Unique page titles, meta descriptions, canonical URLs, Open Graph metadata
- Internal links and WhatsApp enquiry links
- Uses contact number +91 9313268624

IMPORTANT BEFORE PUBLISHING
1. This is a starter package. It does NOT replace your existing homepage.
2. Merge the contents of this folder into the ROOT of your existing GitHub Pages repository.
   Preserve your current index.html, CNAME, admin files, assets and other site files.
3. Check that your canonical domain is exactly https://mapocabs.com. If your preferred
   canonical is https://www.mapocabs.com, change the canonical and og:url values consistently.
4. Confirm the phone number and WhatsApp link are correct and active.
5. Review every service claim. These pages deliberately say availability/pricing are confirmed
   individually and do not promise a guaranteed package, fleet size, 24/7 service or fixed price.
6. Make sure /assets/style.css does not conflict with an existing file of the same name.
7. Add links to /blog/ and /services/ from your current homepage navigation.
8. Do not upload a new sitemap or robots.txt blindly. Merge the URLs into your existing sitemap
   and preserve any existing robots.txt rules.

GOOGLE INDEXING CHECKLIST
- Google Search Console: verify the domain property.
- Submit your sitemap URL (often https://mapocabs.com/sitemap.xml) after updating it.
- Use URL Inspection to request indexing for the new blog and service pages.
- Check the sitemap returns HTTP 200 and lists the canonical URLs.
- Search Console indexing is not guaranteed and rankings take time.

SITEMAP URLS TO ADD
https://mapocabs.com/blog/
https://mapocabs.com/blog/monthly-cab-service-vapi/
https://mapocabs.com/blog/weekly-cab-service-vapi/
https://mapocabs.com/blog/employee-transportation-vapi-sarigam/
https://mapocabs.com/services/
https://mapocabs.com/services/monthly-cab-service-vapi/
https://mapocabs.com/services/weekly-cab-service-vapi/
https://mapocabs.com/services/corporate-cab-service-vapi/
https://mapocabs.com/services/cab-service-vapi-daman-silvassa/

SEO NOTES
- Avoid creating near-identical city pages solely to repeat keywords.
- Add location-specific pages only when they contain useful, accurate local details.
- Update the blog article dates when materially revised.
- Add structured data only when it accurately reflects visible page content and business details.
